import random
from app import app, db, Feedback, User
from werkzeug.security import generate_password_hash

# --- CONFIGURATION ---
DEPARTMENTS = ['CSE', 'ECE', 'EE', 'ME', 'Civil', 'MBA']
CATEGORIES = ['Teachers', 'Labs', 'Infrastructure', 'Library', 'Hostel']
SENTIMENTS = ['Positive', 'Neutral', 'Negative']

# --- NAMES & DATA ---
STUDENT_NAMES = [
    "Aarav", "Vivaan", "Aditya", "Vihaan", "Arjun", "Sai", "Reyansh", "Ayan", "Krishna", "Ishaan",
    "Diya", "Saanvi", "Ananya", "Aadhya", "Pari", "Saanvi", "Riya", "Myra", "Zara", "Sneha",
    "Rahul", "Amit", "Karan", "Vikram", "Neha", "Pooja", "Simran", "Rohan", "Kavya", "Nikhil"
]

TEACHERS = ["Dr. Sharma", "Prof. Verma", "Dr. Gupta", "Ms. Iyer", "Mr. Singh", "Dr. Mehta", "Prof. Das", "Dr. Alok"]
SUBJECTS = ["Data Structures", "Thermodynamics", "Circuits", "Marketing", "Physics", "Algorithms", "Fluid Mechanics"]
LABS = ["Computer Lab 1", "Chemistry Lab", "Workshop", "Physics Lab", "Language Lab", "IoT Lab", "Robotics Lab"]

# --- COMMENTS DATABASE ---
COMMENTS = {
    'Teachers': {
        'Positive': ["Explains concepts very clearly.", "Very supportive and helpful.", "Best teacher ever!", "Classes are engaging."],
        'Neutral': ["Lectures are okay but fast.", "Needs to be more interactive.", "Average teaching style.", "Follows the book strictly."],
        'Negative': ["Always comes late.", "Doesn't clear doubts.", "Very rude behavior.", "Lectures are boring."]
    },
    'Labs': {
        'Positive': ["Equipment is brand new.", "PCs are very fast.", "Lab assistant is helpful.", "Great environment."],
        'Neutral': ["Old equipment but working.", "Internet is slow sometimes.", "Okay for basic practicals."],
        'Negative': ["Computers are not working.", "AC is broken.", "Software licenses expired.", "Very dirty lab."]
    },
    'Infrastructure': {
        'Positive': ["Campus is beautiful.", "Classrooms are clean.", "AC works perfectly.", "Good parking space."],
        'Neutral': ["Water cooler needs repair.", "Fans are noisy.", "Corridors are dark."],
        'Negative': ["Washrooms are unhygienic.", "No lights in class.", "Benches are broken.", "Roof is leaking."]
    },
    'Library': {
        'Positive': ["Great collection of books.", "Very peaceful.", "Good WiFi speed.", "Helpful staff."],
        'Neutral': ["Books are old edition.", "Sometimes noisy.", "Need more seats."],
        'Negative': ["Librarian is rude.", "Books are torn.", "Not enough space.", "AC not working."]
    },
    'Hostel': {
        'Positive': ["Food is tasty.", "Rooms are spacious.", "Wardens are good.", "Clean environment."],
        'Neutral': ["Food is average.", "WiFi is okay.", "Rooms are small."],
        'Negative': ["Mess food is terrible.", "Water shortage issue.", "Too much noise at night.", "Unhygienic washrooms."]
    }
}

def generate_full_comment(category, sentiment):
    """
    Ye function comment ko waisa banayega jaisa hum chahte hain.
    Taaki Admin Dashboard par Teacher ka naam aur Subject saaf dikhe.
    """
    raw_text = random.choice(COMMENTS[category][sentiment])
    
    if category == 'Teachers':
        t_name = random.choice(TEACHERS)
        sub = random.choice(SUBJECTS)
        # Format: [Teacher: Name, Subject: Sub] - Comment
        return f"[Teacher: {t_name}, Subject: {sub}] - {raw_text}"
    
    elif category == 'Labs':
        l_name = random.choice(LABS)
        # Format: [Lab: Name] - Comment
        return f"[Lab: {l_name}] - {raw_text}"
    
    else:
        # Others ke liye simple comment
        return raw_text

def seed_data():
    with app.app_context():
        print("------------------------------------------------")
        print("⚠️  DELETING OLD DATABASE... (Fresh Start)")
        db.drop_all()  # Ye line purana data delete karegi (Zaroori hai)
        db.create_all() # Naya Table banayegi
        print("✅  Database Created!")

        # 1. Create Users
        print("👤 Creating Admin & Student Users...")
        admin = User(username='admin', password_hash=generate_password_hash('admin123'), role='admin')
        student = User(username='student', password_hash=generate_password_hash('student123'), role='student')
        db.session.add(admin)
        db.session.add(student)

        # 2. Generate Feedbacks
        print("📝 Generating Feedbacks...")
        
        feedbacks_list = []
        
        # Har Dept ke liye 30 Feedbacks
        for dept in DEPARTMENTS:
            for _ in range(30): 
                cat = random.choice(CATEGORIES)
                sent = random.choices(SENTIMENTS, weights=[40, 30, 30], k=1)[0]
                
                # Rating Logic
                if sent == 'Positive': rating = random.randint(4, 5)
                elif sent == 'Neutral': rating = 3
                else: rating = random.randint(1, 2)
                
                final_comment = generate_full_comment(cat, sent)
                
                fb = Feedback(
                    student_name=random.choice(STUDENT_NAMES),
                    department=dept,
                    category=cat,
                    rating=rating,
                    sentiment=sent,
                    comment=final_comment  # Ye wo field hai jo Dashboard pe dikhegi
                )
                feedbacks_list.append(fb)

        db.session.add_all(feedbacks_list)
        db.session.commit()
        
        print(f"✅ SUCCESS! Added {len(feedbacks_list)} Feedbacks with Comments.")
        print("------------------------------------------------")
        print("👉 Ab 'python app.py' run karo aur Admin Dashboard check karo.")

if __name__ == '__main__':
    seed_data()