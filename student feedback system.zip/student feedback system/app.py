import os
from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# --- Configuration ---
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
basedir = os.path.abspath(os.path.dirname(__file__))
db_folder = os.path.join(basedir, 'database')
os.makedirs(db_folder, exist_ok=True)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(db_folder, 'feedback.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# --- Database Models ---
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False)

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_name = db.Column(db.String(50))
    department = db.Column(db.String(50))
    category = db.Column(db.String(50)) # Teachers, Labs, Infrastructure, etc.
    rating = db.Column(db.Integer)
    sentiment = db.Column(db.String(20))
    comment = db.Column(db.Text)

# --- Initialize & Seed Data (New Data Logic) ---
def seed_database():
    with app.app_context():
        db.create_all()
        # Create Users
        if not User.query.filter_by(username='admin').first():
            db.session.add(User(username='admin', password_hash=generate_password_hash('admin123'), role='admin'))
        if not User.query.filter_by(username='student').first():
            db.session.add(User(username='student', password_hash=generate_password_hash('student123'), role='student'))
        
        # Check if feedback exists, if not add DUMMY DATA for testing
        if Feedback.query.count() == 0:
            dummy_data = [
                Feedback(student_name="Rahul", department="CSE", category="Teachers", rating=5, sentiment="Positive", comment="Dr. Sharma explains concepts very well!"),
                Feedback(student_name="Priya", department="ECE", category="Labs", rating=2, sentiment="Negative", comment="Equipment in the IoT lab is not working properly."),
                Feedback(student_name="Amit", department="ME", category="Infrastructure", rating=3, sentiment="Neutral", comment="Fans in Room 302 are making noise."),
                Feedback(student_name="Sneha", department="CSE", category="Teachers", rating=2, sentiment="Negative", comment="Classes are not starting on time."),
                Feedback(student_name="Vikram", department="Civil", category="Library", rating=5, sentiment="Positive", comment="Great collection of new books."),
                Feedback(student_name="Rohan", department="IT", category="Hostel", rating=1, sentiment="Negative", comment="Food quality in mess is very bad."),
            ]
            db.session.add_all(dummy_data)
            db.session.commit()
            print("--- Dummy Data Added Successfully ---")

# --- Routes ---
# --- Routes ---

# Yahan humne 2 routes diye hain taaki "URL Not Found" na aaye
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
         
        username = request.form.get('username')
        password = request.form.get('password')

        # 1. Agar field khali hai
        if not username or not password:
            return render_template('login.html', error="Please enter both Username and Password!")

        user = User.query.filter_by(username=username).first()
        
        # 2. Agar User mila aur password match hua
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['role'] = user.role
            session['username'] = user.username
            
            if user.role == 'admin':
                return redirect(url_for('dashboard'))
            else:
                return redirect(url_for('feedback'))
        
        # 3. Agar Password Galat hai (Incorrect)
        else:
            return render_template('login.html', error="Incorrect Username or Password!")
            
    return render_template('login.html')

@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
    if request.method == 'POST':
        new_feedback = Feedback(
            student_name=session['username'],
            department=request.form['department'],
            category=request.form['category'],
            rating=int(request.form['rating']),
            sentiment=request.form['sentiment'],
            comment=request.form['comment']
        )
        db.session.add(new_feedback)
        db.session.commit()
        return redirect(url_for('feedback'))
    my_feedbacks = Feedback.query.filter_by(student_name=session['username']).order_by(Feedback.id.desc()).all()
    return render_template('feedback.html', feedbacks=my_feedbacks, username=session['username'])

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session or session['role'] != 'admin':
        return redirect(url_for('login'))
    
    # Fetch ALL data
    all_feedbacks = Feedback.query.order_by(Feedback.id.desc()).all()
    
    # Categorize data specifically for the new View
    feedbacks_teachers = [f for f in all_feedbacks if f.category == 'Teachers']
    feedbacks_labs = [f for f in all_feedbacks if f.category == 'Labs']
    feedbacks_infra = [f for f in all_feedbacks if f.category in ['Infrastructure', 'Hostel', 'Library']]
    feedbacks_negative = [f for f in all_feedbacks if f.sentiment == 'Negative']

    # Stats
    total = len(all_feedbacks)
    pos = len([f for f in all_feedbacks if f.sentiment == 'Positive'])
    neu = len([f for f in all_feedbacks if f.sentiment == 'Neutral'])
    neg = len(feedbacks_negative)
    
    # Data for Charts
    depts = ['CSE', 'ECE', 'EE', 'MBA', 'IT', 'ME', 'Civil']
    dept_data = {d: {'Positive': 0, 'Neutral': 0, 'Negative': 0} for d in depts}
    for f in all_feedbacks:
        if f.department in dept_data:
            dept_data[f.department][f.sentiment] += 1
            
    return render_template('dashboard.html', 
                           feedbacks=all_feedbacks,
                           feedbacks_teachers=feedbacks_teachers,
                           feedbacks_labs=feedbacks_labs,
                           feedbacks_infra=feedbacks_infra,
                           feedbacks_negative=feedbacks_negative,
                           stats={'total': total, 'pos': pos, 'neu': neu, 'neg': neg},
                           dept_data=dept_data,
                           depts=depts)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    seed_database()
    app.run(debug=True, port=5000)