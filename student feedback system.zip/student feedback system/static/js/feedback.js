// SIDEBAR LOGIC
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.overlay');
    
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// PROFILE MODAL LOGIC
function openProfileModal() {
    document.getElementById('profileModal').style.display = 'block';
    toggleSidebar(); // Close sidebar when modal opens
}

function closeProfileModal() {
    document.getElementById('profileModal').style.display = 'none';
}

// Close modal if clicked outside
window.onclick = function(event) {
    const modal = document.getElementById('profileModal');
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
// 1. Sidebar Toggle Logic
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('main-content');
    
    sidebar.classList.toggle('active');
    content.classList.toggle('active');
}

// 2. Dynamic Form Fields (Teacher/Lab selection)
function handleCategoryChange() {
    const category = document.getElementById('categorySelect').value;
    
    // Elements fetch kar rahe hain
    const teacherSection = document.getElementById('teacher-section');
    const labSection = document.getElementById('lab-section');
    
    // Pehle sab chupa do (Reset)
    teacherSection.style.display = 'none';
    labSection.style.display = 'none';
    
    // Logic: Agar Teachers select kiya toh wo dikhao, Labs kiya toh wo dikhao
    if (category === 'Teachers') {
        teacherSection.style.display = 'block';
        // Input focus kar dete hain taaki user seedha type kare
        document.getElementById('teacherName').focus();
    } else if (category === 'Labs') {
        labSection.style.display = 'block';
        document.getElementById('labName').focus();
    }
}

// 3. Final Data Submission (Merge inputs into one comment)
function prepareSubmission() {
    const category = document.getElementById('categorySelect').value;
    const rawComment = document.getElementById('rawComment').value;
    const finalInput = document.getElementById('finalComment');
    
    let formattedData = "";

    // Data combine kar rahe hain taaki backend change na karna pade
    if (category === 'Teachers') {
        const tName = document.getElementById('teacherName').value || "Unknown";
        const subName = document.getElementById('subjectName').value || "General";
        formattedData = `[Teacher: ${tName}, Subject: ${subName}] \nComment: ${rawComment}`;
    } 
    else if (category === 'Labs') {
        const lName = document.getElementById('labName').value || "General Lab";
        formattedData = `[Lab: ${lName}] \nComment: ${rawComment}`;
    } 
    else {
        // Normal comment
        formattedData = rawComment;
    }

    // Hidden input mein final data daal diya
    finalInput.value = formattedData;

    // Return true taaki form submit ho jaye
    return true;
}