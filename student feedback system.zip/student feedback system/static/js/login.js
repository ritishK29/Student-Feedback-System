// login.js
document.addEventListener('DOMContentLoaded', () => {
    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const container = document.getElementById('container');
    const flashMsg = document.querySelector('.flash-msg');

     
    if (signUpButton) {
        signUpButton.addEventListener('click', () => {
            container.classList.add("right-panel-active");
        });
    }

    // 2. Slide back to Login Form
    if (signInButton) {
        signInButton.addEventListener('click', () => {
            container.classList.remove("right-panel-active");
        });
    }

    // 3. Auto-hide Flash Errors (if any)
    if (flashMsg) {
        setTimeout(() => {
            flashMsg.style.transition = "opacity 0.5s ease";
            flashMsg.style.opacity = "0";
            setTimeout(() => flashMsg.remove(), 500);
        }, 3000);
    }
});