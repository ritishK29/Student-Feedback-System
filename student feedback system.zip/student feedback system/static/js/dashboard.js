// Global Chart Instances (Taaki hum inhe baad mein update kar sakein)
let deptChartInstance = null;
let sentimentChartInstance = null;

document.addEventListener("DOMContentLoaded", function () {
    console.log("Dashboard Loaded!");

    // 1. Hidden Data Fetch Karo
    const dataElement = document.getElementById('chart-data-storage');
    if (!dataElement) return;

    const stats = JSON.parse(dataElement.dataset.stats);
    const deptLabels = JSON.parse(dataElement.dataset.depts);
    const rawDeptData = JSON.parse(dataElement.dataset.deptData);

    // 2. Data Preparation
    const posData = deptLabels.map(d => rawDeptData[d]['Positive']);
    const neuData = deptLabels.map(d => rawDeptData[d]['Neutral']);
    const negData = deptLabels.map(d => rawDeptData[d]['Negative']);

    // 3. Bar Chart Render
    const ctxBar = document.getElementById('deptChart').getContext('2d');
    deptChartInstance = new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: deptLabels,
            datasets: [
                { label: 'Positive', data: posData, backgroundColor: '#10B981' },
                { label: 'Neutral', data: neuData, backgroundColor: '#F59E0B' },
                { label: 'Negative', data: negData, backgroundColor: '#EF4444' }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, scales: { x: { stacked: true }, y: { stacked: true } } }
    });

    // 4. Pie Chart Render
    const ctxPie = document.getElementById('sentimentChart').getContext('2d');
    sentimentChartInstance = new Chart(ctxPie, {
        type: 'doughnut',
        data: {
            labels: ['Positive', 'Neutral', 'Negative'],
            datasets: [{
                data: [stats.pos, stats.neu, stats.neg],
                backgroundColor: ['#10B981', '#F59E0B', '#EF4444'],
                borderWidth: 0
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, cutout: '75%' }
    });
});

// --- MAIN FILTER FUNCTION (Tables + Cards Update karega) ---
function filterTables() {
    const selectedDept = document.getElementById('deptFilter').value;
    
    // 1. Cards Update Karo (Numbers Change Honge)
    updateCards(selectedDept);

    // 2. Tables Filter Karo (Rows Hide/Show Hongi)
    const tables = document.querySelectorAll('.styled-table tbody');

    tables.forEach(tbody => {
        const rows = tbody.querySelectorAll('tr');
        rows.forEach(row => {
            const cells = row.getElementsByTagName('td');
            if (cells.length < 2) return; 

            // Dept column usually 2nd hota hai (Index 1)
            let deptText = cells[1].innerText.trim(); 
            
            // Special Logic for Negative/Issues Tab (Wahan Dept 2nd column hai)
            // Special Logic for Infra Tab (Wahan Dept nahi hota, Category hoti hai)
            
            const commonCategories = ["Infrastructure", "Hostel", "Library", "Canteen", "Sports"];
            const firstCell = cells[0].innerText.trim(); 

            if (selectedDept === 'All') {
                row.style.display = '';
            } else {
                // Agar row ka dept match kare YA wo Infra/Common category ho
                if (deptText === selectedDept || commonCategories.includes(firstCell) || commonCategories.includes(deptText)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    });
}

// --- NEW: CARD UPDATE LOGIC ---
function updateCards(dept) {
    const dataElement = document.getElementById('chart-data-storage');
    const allStats = JSON.parse(dataElement.dataset.stats);      // Overall Stats
    const deptData = JSON.parse(dataElement.dataset.deptData);   // Dept wise breakdown

    // HTML Elements dhoondho (Numbers wale)
    const totalEl = document.querySelector('.card-total .number');
    const posEl = document.querySelector('.card-pos .number');
    const negEl = document.querySelector('.card-neg .number');

    if (dept === 'All') {
        // Agar All hai to wapas purana Total dikhao
        totalEl.innerText = allStats.total;
        posEl.innerText = allStats.pos;
        negEl.innerText = allStats.neg;
        
        // Pie Chart Reset
        updatePieChart([allStats.pos, allStats.neu, allStats.neg]);

    } else {
        // Agar koi Department select kiya hai (e.g., CSE)
        if (deptData[dept]) {
            const d = deptData[dept];
            
            // Calculate New Numbers
            const newTotal = d.Positive + d.Neutral + d.Negative;
            
            // Update Text on Screen
            totalEl.innerText = newTotal;
            posEl.innerText = d.Positive;
            negEl.innerText = d.Negative;

            // Pie Chart Update specific dept ke liye
            updatePieChart([d.Positive, d.Neutral, d.Negative]);
        }
    }
}

// --- HELPER: Update Pie Chart Dynamically ---
function updatePieChart(newData) {
    if (sentimentChartInstance) {
        sentimentChartInstance.data.datasets[0].data = newData;
        sentimentChartInstance.update();
    }
}

// --- SIDEBAR & TABS LOGIC ---
function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('active');
    document.querySelector('.content').classList.toggle('active');
}

function openTab(tabName, btn) {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
    document.getElementById(tabName).style.display = 'block';
    btn.classList.add('active');
}